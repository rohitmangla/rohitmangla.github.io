---
title: "Let's Roll!"
lesson: 2
approx_time: 1 min
---

Now that you have installed Ruby, Jekyll and Bundler, lets get Jekylling!
Enter the following in your terminal:

    $ jekyll new my blog

Then preview your new project in your browser right away by entering the following and pointing your browser to `http://localhost:4000` :

    $ bundle exec jekyll serve

Go ahead. Try it.
